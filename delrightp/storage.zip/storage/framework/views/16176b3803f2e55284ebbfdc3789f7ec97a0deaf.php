<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">
            <?php echo e(__('Copyright © 2021 .')); ?> 
            
            <a href="https://inindiatech.com" class="text-dark" target="_blank">
                <?php echo e(__('inidev,')); ?>

            </a>
            <?php echo e(__(' All Rights Reserved.')); ?> 
        </span>
        <span class="float-right float-sm-right mt-1 mt-sm-0 text-center">
            <?php echo e(__('Hand-crafted & Made with')); ?><i class="fa fa-heart text-danger"></i> 
        </span>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\delright-backend\delright\resources\views/include/footer.blade.php ENDPATH**/ ?>