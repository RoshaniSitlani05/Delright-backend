<div class="app-sidebar colored">
    <div class="sidebar-header">
        <a class="header-brand" href="<?php echo e(route('home')); ?>">
            <div class="logo-img">
                <span>Delright</span>
               <!--<img height="30" src="" class="header-brand-img" title="Delright"> -->
            </div>
        </a>
        <div class="sidebar-action"><i class="ik ik-arrow-left-circle"></i></div>
        <button id="sidebarClose" class="nav-close"><i class="ik ik-x"></i></button>
    </div>

    <?php
        $segment1 = request()->segment(1);
        $segment2 = request()->segment(2);
    ?>
    
    <div class="sidebar-content">
        <div class="nav-container">
            <nav id="main-menu-navigation" class="navigation-main">
                <div class="nav-item <?php echo e(($segment1 == 'dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('home')); ?>"><i class="ik ik-bar-chart-2"></i><span><?php echo e(__('Dashboard')); ?></span></a>
                </div>

            <div class="nav-lavel"><?php echo e(__('Delright')); ?> </div>
                <div class="nav-item <?php echo e(($segment1 == 'users' || $segment1 == 'roles'||$segment1 == 'permission' ||$segment1 == 'user') ? 'active open' : ''); ?> ">
                    <a href="<?php echo e(URL::to('users')); ?>"><i class="ik ik-user"></i><span><?php echo e(__('Users')); ?></span></a>
                </div>
                
                
                <div class="nav-item <?php echo e(($segment1 == 'users' || $segment1 == 'roles'||$segment1 == 'permission' ||$segment1 == 'user') ? 'active open' : ''); ?> ">
                    <a href="<?php echo e(URL::to('vendors')); ?>"><i class="ik ik-user"></i><span><?php echo e(__('Vendors')); ?></span></a>
                </div>
                <div class="nav-item <?php echo e(($segment1 == 'users' || $segment1 == 'roles'||$segment1 == 'permission' ||$segment1 == 'user') ? 'active open' : ''); ?> ">
                    <a href="<?php echo e(URL::to('deliveryusers')); ?>"><i class="ik ik-user"></i><span><?php echo e(__('Delivery Partners')); ?></span></a>
                </div>
                <div class="nav-item <?php echo e(($segment1 == 'users' || $segment1 == 'roles'||$segment1 == 'permission' ||$segment1 == 'user') ? 'active open' : ''); ?> ">
                    <a href="<?php echo e(URL::to('products')); ?>"><i class="ik ik-archive"></i><span><?php echo e(__('products')); ?></span></a>
                </div>
                <div class="nav-item <?php echo e(($segment1 == 'users' || $segment1 == 'roles'||$segment1 == 'permission' ||$segment1 == 'user') ? 'active open' : ''); ?> ">
                    <a href="<?php echo e(URL::to('addCategory')); ?>"><i class="ik ik-user"></i><span><?php echo e(__('Add Categories')); ?></span></a>
                </div>
                
                <div class="nav-item <?php echo e(($segment1 == 'users' || $segment1 == 'roles'||$segment1 == 'permission' ||$segment1 == 'user') ? 'active open' : ''); ?> ">
                    <a href="<?php echo e(URL::to('addMarketProduct')); ?>"><i class="ik ik-user"></i><span><?php echo e(__('Add Market Product')); ?></span></a>
                </div>
                
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\delright-backend\delright\resources\views/include/sidebar.blade.php ENDPATH**/ ?>