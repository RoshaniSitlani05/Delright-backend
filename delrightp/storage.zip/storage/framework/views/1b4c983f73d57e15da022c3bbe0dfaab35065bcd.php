<script src="<?php echo e(asset('all.js')); ?>"></script>
<!-- Stack array for including inline js or scripts -->
<?php echo $__env->yieldPushContent('script'); ?>

<script src="<?php echo e(asset('dist/js/theme.js')); ?>"></script>
<script src="<?php echo e(asset('js/chat.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/forms/wizard/bs-stepper.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\delright-backend\delright\resources\views/include/script.blade.php ENDPATH**/ ?>