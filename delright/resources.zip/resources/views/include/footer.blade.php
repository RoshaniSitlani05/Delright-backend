<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">
            {{ __('Copyright © 2021 .')}} 
            
            <a href="https://inindiatech.com" class="text-dark" target="_blank">
                {{ __('inidev,')}}
            </a>
            {{ __(' All Rights Reserved.')}} 
        </span>
        <span class="float-right float-sm-right mt-1 mt-sm-0 text-center">
            {{__('Hand-crafted & Made with')}}<i class="fa fa-heart text-danger"></i> 
        </span>
    </div>
</footer>